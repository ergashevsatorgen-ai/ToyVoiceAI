# Qo'shimcha qoidalar kerak emas (isMinifyEnabled = false)
