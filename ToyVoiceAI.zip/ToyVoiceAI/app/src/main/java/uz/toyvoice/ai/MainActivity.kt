package uz.toyvoice.ai

import android.Manifest
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.TelephonyManager
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import uz.toyvoice.ai.databinding.ActivityMainBinding
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var prefs: Prefs
    private lateinit var log: ErrorLog
    private val io = Executors.newSingleThreadExecutor()
    private val ui = Handler(Looper.getMainLooper())
    private val voice: VoiceProvider = NoOpVoiceProvider()

    private var job: CallJob? = null
    private var dialingStarted = false
    private var sawOffhook = false
    private var serverOk: Boolean? = null

    private val dialTimeout = Runnable {
        if (dialingStarted && !sawOffhook) finishCall(CallStatus.FAILED, "Qo'ng'iroq boshlanmadi (vaqt tugadi)")
    }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
            if (res[Manifest.permission.CALL_PHONE] == true) confirmAndCall()
            else toast("Qo'ng'iroq qilish uchun ruxsat kerak")
        }

    private val phoneReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (!dialingStarted) return
            when (i?.getStringExtra(TelephonyManager.EXTRA_STATE)) {
                TelephonyManager.EXTRA_STATE_OFFHOOK -> {
                    sawOffhook = true
                    ui.removeCallbacks(dialTimeout)
                }
                TelephonyManager.EXTRA_STATE_IDLE -> {
                    if (sawOffhook) finishCall(CallStatus.COMPLETED, "Qo'ng'iroq tugadi")
                }
            }
        }
    }

    private val netCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { ui.post { refreshStatus() } }
        override fun onLost(network: Network) { ui.post { refreshStatus() } }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        prefs = Prefs(this)
        log = ErrorLog(this)

        b.etToken.setText(prefs.token)

        b.btnConnect.setOnClickListener { onConnect() }
        b.btnCheck.setOnClickListener { checkJobs() }
        b.btnCall.setOnClickListener { onCallClicked() }
        b.btnCancel.setOnClickListener { onCancelClicked() }
        b.btnClearLog.setOnClickListener { log.clear(); renderLog() }
        b.tvVoiceInfo.text = "AI ovoz: ${voice.name}"

        ContextCompat.registerReceiver(
            this, phoneReceiver,
            IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED),
            ContextCompat.RECEIVER_EXPORTED
        )
        (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager)
            .registerDefaultNetworkCallback(netCallback)

        renderJob()
        renderLog()
        refreshStatus()
        requestPhonePermissionsIfNeeded()
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(phoneReceiver) } catch (_: Exception) {}
        try {
            (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager)
                .unregisterNetworkCallback(netCallback)
        } catch (_: Exception) {}
        ui.removeCallbacksAndMessages(null)
        io.shutdown()
    }

    // ---------- Holat ----------
    private fun isOnline(): Boolean {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun refreshStatus() {
        b.tvNet.text = if (isOnline()) "● Internet: ONLINE" else "● Internet: OFFLINE"
        b.tvNet.setTextColor(color(if (isOnline()) R.color.ok else R.color.err))

        val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val ready = tm.simState == TelephonyManager.SIM_STATE_READY
        val op = tm.networkOperatorName?.takeIf { it.isNotBlank() } ?: "noma'lum"
        b.tvSim.text = if (ready) "● SIM: tayyor ($op)" else "● SIM: tayyor emas"
        b.tvSim.setTextColor(color(if (ready) R.color.ok else R.color.err))

        when (serverOk) {
            true -> { b.tvServer.text = "● Server: ulangan"; b.tvServer.setTextColor(color(R.color.ok)) }
            false -> { b.tvServer.text = "● Server: xatolik"; b.tvServer.setTextColor(color(R.color.err)) }
            null -> { b.tvServer.text = "● Server: tekshirilmagan"; b.tvServer.setTextColor(color(R.color.muted)) }
        }
    }

    private fun color(id: Int) = ContextCompat.getColor(this, id)

    // ---------- Server ----------
    private fun onConnect() {
        val t = b.etToken.text?.toString()?.trim().orEmpty()
        if (t.isEmpty()) { toast("Tokenni kiriting"); return }
        prefs.token = t
        toast("Token saqlandi")
        checkJobs()
    }

    private fun checkJobs() {
        val t = prefs.token
        if (t.isEmpty()) { toast("Avval token kiriting"); return }
        if (!isOnline()) { serverOk = false; refreshStatus(); toast("Internet yo'q"); return }
        if (dialingStarted) { toast("Qo'ng'iroq davom etmoqda"); return }
        setBusy(true)
        io.execute {
            val r = ApiClient.fetchNext(t)
            ui.post {
                setBusy(false)
                if (!r.ok) {
                    serverOk = false
                    val why = when {
                        r.error != null -> "Tarmoq xatosi: ${r.error}"
                        r.code == 401 || r.code == 403 -> "Token noto'g'ri yoki ruxsat yo'q (${r.code})"
                        else -> "Server xatosi: HTTP ${r.code}"
                    }
                    log.add(why); renderLog(); toast(why)
                } else {
                    serverOk = true
                    val j = ApiClient.parseJob(r.body)
                    job = j
                    if (j == null) toast("Yangi topshiriq yo'q")
                    renderJob()
                }
                refreshStatus()
            }
        }
    }

    private fun postStatus(callId: String, status: String) {
        val t = prefs.token
        io.execute {
            val r = ApiClient.sendStatus(t, callId, status)
            if (!r.ok) ui.post {
                log.add("Status yuborilmadi ($status): " + (r.error ?: "HTTP ${r.code}"))
                renderLog()
            }
        }
    }

    // ---------- Qo'ng'iroq ----------
    private fun requestPhonePermissionsIfNeeded() {
        val need = listOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    private fun onCallClicked() {
        val j = job ?: run { toast("Topshiriq yo'q"); return }
        if (dialingStarted) return
        if (normalize(j.phone).length < 9) { toast("Telefon raqami noto'g'ri"); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            permLauncher.launch(arrayOf(Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE))
            return
        }
        confirmAndCall()
    }

    private fun confirmAndCall() {
        val j = job ?: return
        val serverConsent = j.consent
        val msg = "${j.guestName.ifEmpty { "Mehmon" }}\n${j.phone}\n\n" +
                "Bu AVTOMATIK taklif qo'ng'irog'i. Faqat mehmon rozilik bergan bo'lsa qo'ng'iroq qiling.\n" +
                "Qo'ng'iroq YOZIB OLINMAYDI."
        var checked = serverConsent
        val builder = AlertDialog.Builder(this)
            .setTitle("Qo'ng'iroqni tasdiqlang")
            .setNegativeButton("Bekor", null)
        if (serverConsent) {
            builder.setMessage(msg + "\n\nServer: mehmon roziligi bor ✔")
        } else {
            builder.setMessage(msg)
            builder.setMultiChoiceItems(arrayOf("Mehmon qo'ng'iroqqa rozilik bergan"), booleanArrayOf(false)) { _, _, c ->
                checked = c
            }
        }
        builder.setPositiveButton("Qo'ng'iroq qilish") { _, _ ->
            if (!checked) {
                toast("Rozilik tasdiqlanmadi. Qo'ng'iroq qilinmadi.")
                log.add("Rozilik yo'q: qo'ng'iroq bloklandi (${j.callId})"); renderLog()
            } else startCall(j)
        }
        builder.show()
    }

    private fun startCall(j: CallJob) {
        try {
            dialingStarted = true
            sawOffhook = false
            postStatus(j.callId, CallStatus.DIALING)
            voice.onCallStarted(j)
            setResult("Qo'ng'iroq boshlandi…", R.color.muted)
            val intent = Intent(Intent.ACTION_CALL, Uri.fromParts("tel", normalize(j.phone), null))
            startActivity(intent)
            ui.postDelayed(dialTimeout, 45000)
            renderJob()
        } catch (e: SecurityException) {
            finishCall(CallStatus.FAILED, "Ruxsat yo'q: ${e.message}")
        } catch (e: Exception) {
            finishCall(CallStatus.FAILED, "Qo'ng'iroq xatosi: ${e.message}")
        }
    }

    private fun finishCall(status: String, note: String) {
        val j = job ?: return
        ui.removeCallbacks(dialTimeout)
        dialingStarted = false
        sawOffhook = false
        voice.onCallEnded(j)
        postStatus(j.callId, status)
        if (status == CallStatus.FAILED) { log.add("${j.callId}: $note"); renderLog() }
        val c = if (status == CallStatus.COMPLETED) R.color.ok else R.color.err
        setResult("Natija: $status — $note", c)
        job = null
        renderJob()
    }

    private fun onCancelClicked() {
        val j = job ?: return
        if (dialingStarted) { toast("Qo'ng'iroq boshlangan, uni telefondan tugating"); return }
        postStatus(j.callId, CallStatus.CANCELLED)
        setResult("Natija: cancelled — topshiriq bekor qilindi", R.color.muted)
        job = null
        renderJob()
    }

    /** +998 bilan boshlanmasa va 9 xonali bo'lsa, +998 qo'shadi. */
    private fun normalize(raw: String): String {
        val digits = raw.filter { it.isDigit() || it == '+' }
        return if (!digits.startsWith("+") && digits.length == 9) "+998$digits"
        else if (!digits.startsWith("+") && digits.length == 12 && digits.startsWith("998")) "+$digits"
        else digits
    }

    // ---------- UI ----------
    private fun renderJob() {
        val j = job
        if (j == null) {
            b.tvGuestName.text = "Mehmon: —"
            b.tvGuestPhone.text = "Telefon: —"
            b.tvInvite.text = "Taklif matni: topshiriq yo'q"
            b.btnCall.isEnabled = false
            b.btnCancel.isEnabled = false
        } else {
            b.tvGuestName.text = "Mehmon: ${j.guestName.ifEmpty { "—" }}"
            b.tvGuestPhone.text = "Telefon: ${j.phone}"
            b.tvInvite.text = j.inviteText.ifEmpty { "(matn berilmagan)" }
            b.btnCall.isEnabled = !dialingStarted
            b.btnCancel.isEnabled = !dialingStarted
        }
    }

    private fun setResult(text: String, colorRes: Int) {
        b.tvResult.text = text
        b.tvResult.setTextColor(color(colorRes))
    }

    private fun renderLog() {
        val l = log.lines()
        b.tvLog.text = if (l.isEmpty()) "Xatolar yo'q" else l.joinToString("\n")
    }

    private fun setBusy(busy: Boolean) {
        b.progress.visibility = if (busy) View.VISIBLE else View.GONE
        b.btnConnect.isEnabled = !busy
        b.btnCheck.isEnabled = !busy
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
