package uz.toyvoice.ai

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Xatolar tarixi. Token va sarlavhalar HECH QACHON bu yerga yozilmaydi. */
class ErrorLog(context: Context) {

    private val sp = context.getSharedPreferences("toyvoice_log", Context.MODE_PRIVATE)
    private val fmt = SimpleDateFormat("dd.MM HH:mm:ss", Locale.US)

    fun add(message: String) {
        val line = "${fmt.format(Date())}  ${sanitize(message)}"
        val list = lines().toMutableList()
        list.add(0, line)
        while (list.size > 50) list.removeAt(list.size - 1)
        sp.edit().putString("log", list.joinToString("\n")).apply()
    }

    fun lines(): List<String> {
        val s = sp.getString("log", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split("\n")
    }

    fun clear() { sp.edit().remove("log").apply() }

    private fun sanitize(s: String): String =
        s.replace(Regex("(?i)bearer\\s+\\S+"), "Bearer ***").take(300)
}
