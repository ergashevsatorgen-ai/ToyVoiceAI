package uz.toyvoice.ai

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object ApiClient {

    private const val BASE =
        "https://69aeb6d8d46da.myxvest2.ru/Barchabotlar/sim/index.php"

    data class Result(val code: Int, val body: String, val error: String? = null) {
        val ok get() = error == null && code in 200..299
    }

    /** Navbatdagi topshiriq (GET). Orqa oqimda chaqiring. */
    fun fetchNext(token: String): Result = request("GET", "device/next", token, null)

    /** Qo'ng'iroq holatini yuborish (POST). Orqa oqimda chaqiring. */
    fun sendStatus(token: String, callId: String, status: String): Result {
        val json = JSONObject().put("call_id", callId).put("status", status).toString()
        return request("POST", "device/status", token, json)
    }

    private fun request(method: String, api: String, token: String, json: String?): Result {
        var conn: HttpURLConnection? = null
        return try {
            conn = (URL("$BASE?api=$api").openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 15000
                readTimeout = 20000
                setRequestProperty("Authorization", "Bearer $token")
                setRequestProperty("Accept", "application/json")
                if (json != null) {
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
                }
            }
            val code = conn.responseCode
            val stream = if (code in 200..399) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            Result(code, body)
        } catch (e: Exception) {
            Result(-1, "", e.javaClass.simpleName + ": " + (e.message ?: ""))
        } finally {
            conn?.disconnect()
        }
    }

    /**
     * Server javobini moslashuvchan o'qiydi. Qo'llab-quvvatlanadigan shakllar:
     *  {"call_id":..,"name":..,"phone":..,"text":..}
     *  {"ok":true,"data":{...}}  /  {"job":{...}}  /  {"task":{...}}  /  {"call":{...}}
     * Topshiriq yo'q bo'lsa null qaytaradi.
     */
    fun parseJob(body: String): CallJob? {
        if (body.isBlank()) return null
        val root = try { JSONObject(body) } catch (e: Exception) { return null }
        var o: JSONObject = root
        for (k in listOf("data", "job", "task", "call")) {
            val inner = root.optJSONObject(k)
            if (inner != null) { o = inner; break }
        }
        val id = firstString(o, "call_id", "id", "job_id", "task_id")
        val phone = firstString(o, "phone", "guest_phone", "number", "tel")
        if (id.isEmpty() || phone.isEmpty()) return null
        return CallJob(
            callId = id,
            guestName = firstString(o, "name", "guest_name", "full_name", "fio"),
            phone = phone,
            inviteText = firstString(o, "text", "message", "invite_text", "script"),
            consent = o.optBoolean("consent", false) ||
                    o.optBoolean("consent_given", false) ||
                    o.optBoolean("agreed", false)
        )
    }

    private fun firstString(o: JSONObject, vararg keys: String): String {
        for (k in keys) {
            if (o.has(k) && !o.isNull(k)) {
                val v = o.optString(k, "").trim()
                if (v.isNotEmpty()) return v
            }
        }
        return ""
    }
}
