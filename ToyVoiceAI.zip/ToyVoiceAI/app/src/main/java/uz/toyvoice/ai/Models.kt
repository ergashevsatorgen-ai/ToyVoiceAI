package uz.toyvoice.ai

/** Serverdan kelgan bitta qo'ng'iroq topshirig'i. */
data class CallJob(
    val callId: String,
    val guestName: String,
    val phone: String,
    val inviteText: String,
    /** Server mehmon rozilik bergani haqida aniq true yuborgan bo'lsa true. */
    val consent: Boolean
)

object CallStatus {
    const val DIALING = "dialing"
    const val COMPLETED = "completed"
    const val FAILED = "failed"
    const val CANCELLED = "cancelled"
}
