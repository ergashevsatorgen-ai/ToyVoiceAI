package uz.toyvoice.ai

/**
 * KELGUSI VERSIYA UCHUN ARXITEKTURA.
 *
 * Android 11 da oddiy ilova TTS ovozini GSM qo'ng'iroqning narigi tomoniga
 * uzata OLMAYDI. AI ovoz uchun GSM gateway, SIP/VoIP yoki telephony platformasi
 * (qonuniy va texnik mos yechim) kerak. Bu interfeys o'sha yechim ulanadigan joy.
 *
 * Hozir faqat [NoOpVoiceProvider] bor: ovoz uzatilmaydi, matn ekranda ko'rsatiladi.
 */
interface VoiceProvider {
    val name: String
    val supportsLiveVoice: Boolean
    /** Qo'ng'iroq boshlanganda chaqiriladi. */
    fun onCallStarted(job: CallJob)
    /** Qo'ng'iroq tugaganda chaqiriladi. */
    fun onCallEnded(job: CallJob)
}

class NoOpVoiceProvider : VoiceProvider {
    override val name = "Ovoz uzatish yo'q (matn ekranda)"
    override val supportsLiveVoice = false
    override fun onCallStarted(job: CallJob) {}
    override fun onCallEnded(job: CallJob) {}
}
