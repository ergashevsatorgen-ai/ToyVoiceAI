package uz.toyvoice.ai

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Token shifrlangan (EncryptedSharedPreferences) holda saqlanadi.
 * Qayta yoqilganda ham saqlanib qoladi.
 */
class Prefs(context: Context) {

    private val sp: SharedPreferences = try {
        val key = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "toyvoice_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Shifrlash ishlamasa ham ilova ochilsin (token baribir private xotirada)
        context.getSharedPreferences("toyvoice_fallback", Context.MODE_PRIVATE)
    }

    var token: String
        get() = sp.getString("token", "") ?: ""
        set(v) { sp.edit().putString("token", v.trim()).apply() }

    fun clearToken() { sp.edit().remove("token").apply() }
}
