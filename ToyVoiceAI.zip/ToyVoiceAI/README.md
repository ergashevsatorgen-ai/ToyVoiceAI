# To‘y Voice AI — Android loyihasi

Kotlin, minSdk 26, targetSdk 33, Android 11 (Tecno Spark 8P) bilan mos.

## APK yig‘ish
1. Android Studio (Hedgehog yoki yangiroq) o‘rnating, `ToyVoiceAI` papkasini oching.
2. Gradle sync tugashini kuting (internet kerak, Gradle 8.5 avtomatik yuklanadi).
3. `Build → Build Bundle(s) / APK(s) → Build APK(s)`.
4. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Muqobil: loyihani GitHub'ga yuklang, `Actions` bo‘limida APK avtomatik yig‘iladi.

## Telefonga o‘rnatish
APK ni telefonga o‘tkazing → "Noma'lum manbalardan o‘rnatish"ga ruxsat bering → o‘rnating.
Birinchi ochilganda "Qo‘ng‘iroq" va "Telefon holati" ruxsatlarini bering.

## Server javobi formati
Ilova quyidagilarni tushunadi (kalitlar variantlari ham bor, `ApiClient.parseJob`):
`{"call_id":"..","name":"..","phone":"+998..","text":"..","consent":true}`
yoki `data` / `job` / `task` / `call` ichida. Topshiriq bo‘lmasa bo‘sh javob yoki `call_id`siz javob.
`consent:true` kelmasa, operator qo‘ng‘iroq oldida rozilikni qo‘lda tasdiqlaydi.

## Muhim cheklovlar
- AI ovozini qo‘ng‘iroq ichiga uzatish Android 11 oddiy ilovasida MUMKIN EMAS.
  `VoiceProvider.kt` kelajakda GSM gateway / SIP ulash uchun tayyor arxitektura.
- "completed" = qo‘ng‘iroq ulanib, keyin tugagan. Mehmon javob bergan-bermaganini aniqlamaydi.
- Qo‘ng‘iroq yozib olinmaydi.
- Qo‘ng‘iroq holatini kuzatish uchun ilova qo‘ng‘iroq paytida xotirada turishi kerak.
